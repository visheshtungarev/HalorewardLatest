import { Button, Checkbox, Col, Form, Input, Row } from "antd";
import React from "react";
import { EyeOutlined } from "@ant-design/icons";
import "./index.css";
import { Link } from "react-router-dom";
import action from "../../actions";

export default function Login({ goToRegister, forgotPwd }) {
  function onChange(e) {
    console.log(`checked = ${e.target.checked}`);
  }
  const getAuthentication = async () => {
    try {
      let resp = await action.LOGINACTION();
      console.log("response>>>", resp);
    } catch (error) {
      console.log("error", error);
    }
  };

  return (
    <Form autoComplete="new-password">
      <div className="mb-4">
        <label>Email</label>
        <div className="lineinput">
          <Input
            placeholder="Email"
            autoComplete="new-password"
            type={"email"}
          />
        </div>
      </div>
      <div className="mb-4">
        <label>Password</label>
        <div className="lineinput">
          <Input
            placeholder="Password"
            autoComplete="new-password"
            type={"password"}
            suffix={<EyeOutlined />}
          />
        </div>
      </div>
      <Row className="pb-4">
        <Col span={12}>
          <Checkbox onChange={onChange}>Remember Me</Checkbox>
        </Col>
        <Col span={12} className="text-right">
          <Link
            to=""
            onClick={() => forgotPwd()}
            className="text-decoration-none"
          >
            Forgot password?
          </Link>
        </Col>
      </Row>
      <div className="mb-4">
        <Button
          onClick={() => {
            getAuthentication();
          }}
          type="primary"
          className="w-100"
          size="large"
        >
          Login
        </Button>
      </div>
      <div className="mb-4 d-flex align-items-center justify-content-center">
        <span className="orDevider">or</span>
      </div>
      <div className="mb-4 text-center">
        <p className="fw-bold">Sign in with</p>
        <a href="google.com" target="_blank">
          <img src="/Images/google.svg" height={40} />
        </a>{" "}
        &nbsp;
        <a href="facebook.com" target="_blank">
          <img src="/Images/facebook.svg" height={40} />
        </a>
      </div>
      <div className="py-md-4 py-0"></div>
      <div className="mb-4 text-center fw-bold">
        Don’t have an account yet? &nbsp;
        <Link to="" onClick={() => goToRegister()}>
          Register
        </Link>
      </div>
    </Form>
  );
}
