import React from "react";

const Homepage = () => {
  return (
    <div style={{ background: "red" }}>
      <h1> Hello </h1>
    </div>
  );
};

export default Homepage;
