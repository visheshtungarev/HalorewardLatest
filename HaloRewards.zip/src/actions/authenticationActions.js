
import { LOGINSUCCESS } from "../Constants/ActionsConstants";
import env from "../enviroment";
import { Post_call, setToken } from "../network/networkmanager"

const values = env();
const LOGINACTION = (payload) => async (dispatch) => {
  console.log("payload",payload)
  const { auth } = values;
  try {
    //start loader with dispatch
    let response = await Post_call(`${auth}/login`);
    if (response.status === 200) {
      setToken(response.data.data.access_token);
      dispatch({
        type: LOGINSUCCESS,
        payload: response.data.data,
      });
    }
  } catch (error) {
    console.error(error);
    throw error;
  } finally {
    //end the loader with dispatch
  }
};

export { LOGINACTION };
