export const LOGINSUCCESS = "login_success";
export const SETPREFERENCE = "set_preference";
