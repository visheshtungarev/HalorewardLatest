export const LOGINSUCCESS = "login_success";
export const SIGNUPSUCCESS = "signup_success";
export const PASSWORDSUCCESS = "password_success";
export const SETPREFERENCE = "set_preference";
export const SETSYSTEMTOKEN ="set_system_token";
export const BRANDSEARCH ="BRAND_SEARCH";
export const BRANDENTER ="BRAND_ENTER";
export const BRANDLIST ="BRAND_LIST";
export const RESETBRAND ="RESET_BRAND";
export const TOGGLELOADING ="TOGGLE_LOADING";
export const GETCAROUSEL ="GETCAROUSEL";

